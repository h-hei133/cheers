# NormProof

NormProof is a Norm Engineering Runtime for AI Agents. It turns architectural and engineering norms into executable, verifiable, deterministic runtime constraints and proof verdicts.

The central principle: **Host claimed complete is not the same as proven complete.**

NormProof evaluates whether an agent's completion claim is backed by deterministic evidence ($A_0/A_1$) rather than self-narrative ($A_4$). It operates statelessly, uses a pinned TypeScript parser, and provides four delivery surfaces over a single judgement kernel.

---

## Quickstart

For a trial in another workspace, install the built `normproof-0.1.0.tgz` as a local dev dependency.
Use `npx --no-install normproof` from that workspace to run the installed command.

Initialize the workspace and accept its baseline before judging it.

```bash
# 1. Detect workspace layout and generate .normproof/ configuration
normproof init

# 2. Record what this workspace already is — the state later judgements compare against
normproof baseline accept

# 3. Judge the workspace against its declared norms
normproof judge
```

**Why step 2 exists.** A generated norm pack should not assert a number about a codebase its author has
never seen. The responsibility ceiling compares each module against the size *this workspace accepted*,
recorded per module path in a committed `.normproof/baseline.json`; `baseline accept` writes that file from what the
collector measures. The file is ordinary evidence — commit it, review changes to it, and read a change
as the statement "this workspace accepted a new state".

Judging without a baseline is a judgement, not an error: the ceiling reports a typed read failure,
`missing`, and the verdict says so. Re-running `baseline accept` after a deliberate decision is how a
workspace raises its own bound; it is a reviewed act rather than a side effect of adding code.

### Exit Codes

- `0`: **proven** / **partial** — all blocking obligations hold. (`partial` means only advisory obligations are open; pass `--fail-on advisory` to exit 2 on advisory gaps).
- `2`: **not proven** — one or more blocking obligations are open or failed (or advisory obligations when `--fail-on advisory` is set).
- `1`: **could not judge** — invalid input, missing profile, unreadable workspace, or runtime error.

---

## Four Delivery Surfaces

NormProof claims four ways to consume a single norm pack:

### 1. Command Line Interface (CLI)
- `normproof init` generates `.normproof/` with portable norms (`software-structure-v0`) for the detected source tree or declared TypeScript workspace packages. `--host` and `--ci github` print configuration fragments for the selected integration.
- `normproof judge`: Evaluates the workspace against its declared norm profile and produces `verdict.json`, `ledger.json`, and diagnostics.
- `normproof prose`: Compiles the active profile, evidence manifest, and write rules into instructions. Use `--sync` to update only the managed block in `AGENTS.md`. Use `--check` in CI to detect drift (exit 2). Invalid or unreadable configuration exits 1.
- `normproof baseline accept`: Records the measurements a later judgement compares against, refusing to write when any declared evidence could not be read.
- `normproof gate write`: Pre-write hook command that denies violating writes before they land.
- `normproof gate stop`: Completion hook command that blocks `Stop` while blocking obligations remain open.

`report.md` lists missing and failed obligations at all severities; the structured
`openBlockingObligations` summary and enforcement remain blocking-only. Successful runs declare seven
existing paths in `sidecar-result.json`. `--include-audit-artifacts` (also `--with-audit-artifacts`)
adds the three emitted audit paths: context bundle, norm review, and feedback proposal. A failed
invocation declares only its result file, or no path if that write could not be confirmed.

### 2. Continuous Integration (CI)
Run the sidecar check runner in CI pipelines with native platform output formats:

`normproof judge --format text` prints readable diagnostics. `normproof judge --format github` prints
GitHub Actions annotations with workspace-relative paths and source coordinates when available.
The default stdout format is the `sidecar-result.json` envelope. SARIF and JUnit add an artifact
while keeping that stdout format. All formats use the same exit policy and write the same
judgement artifacts.

```bash
# Standard output with open-obligations-summary.json
npm run sidecar:run -- .normproof/judge-input.json .normproof/out --evidence-manifest .normproof/evidence-manifest.json

# GitHub Code Scanning / GitLab SAST (SARIF v2.1.0)
npm run sidecar:run -- .normproof/judge-input.json .normproof/out --evidence-manifest .normproof/evidence-manifest.json --format sarif
# Test-runner XML (JUnit format) with strict failure on advisory gaps
npm run sidecar:run -- .normproof/judge-input.json .normproof/out --evidence-manifest .normproof/evidence-manifest.json --format junit --fail-on advisory
```

When no format flag is specified, existing artifacts remain byte-identical. Pass `--fail-on advisory` to enforce strict zero-advisory-gap policies in CI.

Choose the consumer's exit policy explicitly:

| Policy | Invocation and exit meaning |
| --- | --- |
| Blocking | `normproof judge --fail-on blocking` (default): 0 for proven or advisory-only partial; 2 for open/failed blocking obligations. |
| Advisory | `normproof judge --fail-on advisory`: also exit 2 for advisory gaps; obligation severity and enforcement records stay unchanged. |
| Observation | A workflow that records the verdict and then forces `exit 0` measures outcomes without enforcing them. Its green job is not proof that obligations hold. |

Both judge thresholds return 1 when no judgement can be produced. A release gate must propagate
both 1 and 2 as failures and retain the verdict artifacts. Output format does not change the policy.
**The watch workflow is observation, not a gate.** A watch workflow that forces `exit 0` cannot be used
as release-gate evidence, even when its job is green; inspect the recorded verdict separately.

### 3. Host Agent Hooks
Paste the hook configuration printed by `normproof init` into your agent host configuration (e.g. `.codex/config.toml` or Claude Code settings):

```toml
[[hooks.PreToolUse]]
[[hooks.PreToolUse.hooks]]
type = "command"
command = "normproof gate write"

[[hooks.Stop]]
[[hooks.Stop.hooks]]
type = "command"
command = "normproof gate stop"
```

The completion gate shows up to three blocking obligations with their locations and next repair
actions. Send the same `session_id` on the initial Stop and subsequent re-entries to enable up to
three blocks per repair chain. A re-entry continues only when the current judge confirms that the
blocking gap set strictly shrank. Without correlation, the gate yields after its first block.
Stalled chains yield to the independent judgement in continuous integration.

Adapters that need a machine result can invoke `normproof gate write --emit-result`. It emits one JSON
object `{ decision, reasonCode, reason }` for every outcome. The decision is `allow`, `block`, or
`allow_with_advisory`. Advisory results include `additionalContext` for the host to pass along.
An allow result is a gate disposition and grants neither host permission nor proof of completion.
Default hook behavior is unchanged: allow emits nothing and deny emits the host permission frame.
The opt-in result replaces that frame, so its consuming adapter must apply the result explicitly.

Hosts may also invoke `normproof gate write --stdio` for a bounded sequence of checks. Send one
UTF-8 JSON-RPC request per line with an integer `id`, the method `writeGate/check`, and the same hook
payload in `params`. Replies are serial and carry the same result as `--emit-result`. Each request
reads current workspace rules and source stamps. The host owns the process lifetime and may invoke
the single-request command again if transport fails. The independent `judge` reads source directly.

To check local package imports, set `workspaceSourceCondition` on the graph source in the evidence
manifest and on the write rules. NormProof reads the root manifest's explicit `workspaces` paths
and the declared package `exports` in the same workspace. The named condition selects source
entries. Type-only imports use the declared `types` entry when present. A known package's private
or unavailable entry leaves a graph gap. A write assessment that includes package manifests
reports incomplete evidence until the resulting workspace can be judged.

### 4. Protocol Endpoint (MCP Stdio)
NormProof serves discovery, workspace judgement, single-file write checks, and norm prose compilation
over newline-delimited JSON-RPC 2.0 stdio (`src/adapters/protocol/stdio-server.ts`). `initialize`
supports `2026-07-28` and `2025-11-25`, echoes a supported request revision and advertises
`capabilities.tools.listChanged: false`. Unsupported revisions receive deterministic `-32602` with
the complete supported set. Initialized notifications receive no response; `ping` returns an empty
result. Existing direct discovery and tool calls remain available without a judgement session.
The server has no runtime SDK dependency; the pinned SDK is used only for client acceptance tests.

---

## Norm Packs & The Single Source

NormProof treats norm packs as machine-readable single sources of truth that compile to both machine rules and human/agent prose:

- **`src/engine/norm-prose-compiler.ts`**: Single-source compiler that translates all 14 obligation expression kinds into natural language instructions for agent prompts (`AGENTS.md` / system instructions).
- **`software-structure-v0`**: The default portable pack generated by `normproof init` for foreign codebases:
  1. `source_graph_is_acyclic` (advisory): Detects import cycles among source modules.
  2. `source_graph_has_no_unresolved_specifiers` (blocking): Asserts that all import specifiers resolve within the graph.
  3. `declared_functions_within_module_ceiling` (advisory): Bounds responsibility centralization per module against the count accepted for that module path, recorded in `.normproof/baseline.json`. The measured zero-false-positive rate that justified the advisory tier came from the calibration corpus; the bound each workspace is held to is its own.
- **`repository-engineering-v0`**: This repository's own 19-obligation self-description used for dogfood verification and vacuity testing.

Generated packs no longer impose a source-file volume obligation. Byte, path, and graph acquisition
limits remain bounded-resource safeguards with typed `oversized` failures, separate from module quality.
For supported source trees, `init` generates version `0.2.0` write rules for newly introduced
runtime cycles and growth beyond accepted per-module function counts. Run `normproof baseline accept`
to establish the function baseline. Declare any project-specific dependency directions in the pack
and write rules after deciding which layers may depend on each other.
The generated matcher is `^(?:Write|Edit|MultiEdit|NotebookEdit)$`; host-specific names must be mapped
by the host adapter or reported unsupported.

---

## Evidence Authority & Concept

Host final answers are low-authority A4 claim evidence. They can prove that a host answered, but cannot prove task completion or replace required A0 or A1 evidence.

Evidence authority levels:
- **`A0`**: Deterministic tool, verifier, runtime, or filesystem evidence.
- **`A1`**: Original task, manifest, or trusted run configuration evidence.
- **`A2`**: Explicit human approval or governance decision.
- **`A3`**: Model analysis, summaries, or repair suggestions.
- **`A4`**: Host final answer or completion self-claim.

`A3` and `A4` claims may explain or summarize, but can **never** replace `A0` or `A1` evidence for a blocking obligation.

---

## Sidecar Check Contract & Proof Artifacts

NormProof exposes a host-neutral sidecar check contract through `src/contracts/sidecar/sidecar-contracts.ts` and a compact context bundle generator in `src/contracts/artifacts/context-bundle-contracts.ts` and `src/runtime/context-bundle.ts`.

The current sidecar output contract version is `0.22.0`.

All stable public sidecar file-run artifact paths are:
- `verdict.json`: Machine verdict (`status`: `proven` | `partial` | `not_proven` | `failed`).
- `ledger.json`: Complete proof accounting artifact with obligations, evidence bindings, and derivation.
- Manifest-based judgement writes ledger 0.9 with an evidence envelope recording source byte hashes,
  collector/profile versions, actual per-evidence limits and capture failures. Pre-built legacy evidence
  retains ledger 0.8. See [the evidence contract](docs/evidence-contract-execution.md) for field sources.
- `enforcement.json`: Enforcement record with wouldBlock/didBlock decision facts.
- `open-obligations-summary.json`: Locates unmet obligations and concrete repair items.
- `report.md`: Human-readable summary projection.
- `evidence/run-trace.jsonl`: Execution trace log.
- `context-bundle.json`: Compact context for downstream agent consumption.
- `norm-review-result.json`: Audit artifact for provenance review.
- `feedback-to-norm-proposal.json`: Advisory diagnostic proposals.
- `sidecar-result.json`: Public command result envelope.

---

## Package Installation & Execution Boundary

The installed package supports Node.js 20.3.0 or later. Linux CI tests the installed runtime on Node.js 20.3.0 and 24. Repository development uses Node.js 24 for the build and test toolchain. Installation resolves the pinned TypeScript 5.9.3 parser and `yaml` 2.8.3 (`pnpm-workspace.yaml` reader) from the registry.

The installed `normproof` command is the executable-only public surface; package-root and undeclared subpath imports are blocked by package exports and fail with `ERR_PACKAGE_PATH_NOT_EXPORTED`.

To build, pack, and verify installed execution:

```bash
npm run build
archive_dir="$(mktemp -d)"
consumer_dir="$(mktemp -d)"
npm pack --pack-destination "$archive_dir"
npm install --omit=dev --prefix "$consumer_dir" "$archive_dir"/normproof-*.tgz
"$consumer_dir"/node_modules/.bin/normproof --help
cd /absolute/path/to/workspace && "$consumer_dir"/node_modules/.bin/normproof init
"$consumer_dir"/node_modules/.bin/normproof judge
rm -rf "$archive_dir" "$consumer_dir"
```

source execution uses `npm test` and `node --import tsx`; installed execution uses `node_modules/.bin/normproof` with native ESM and pre-bundled `norm-packs`.

---

## Current Technical Solution Snapshot

The active boundaries and implementation ownership are defined in `docs/architecture/current-implementation-system-map.md`:

- **Proof Kernel**: `src/core`, `src/engine`, and `src/runtime/sidecar-check-run.ts` derive proof results from explicit evidence.
- **Delivery Surfaces**: CLI (`src/adapters/cli`), Host Hooks (`src/adapters/completion-gate`), CI Builders (`src/engine/artifacts/sarif-report-builder.ts`, `src/engine/artifacts/junit-report-builder.ts`), and MCP Stdio Protocol Server (`src/adapters/protocol/stdio-server.ts`).
- **Proof Truth**: `verdict.json` and `ledger.json` remain proof truth. Reports, summaries, traces, and context bundles are projections.

---

## Development & Verification

Build the package archive and standalone hooks from a clean checkout with the locked dependencies installed:

```bash
npm ci
npm run package:artifacts -- "$(git rev-parse HEAD)" /path/to/new-output-directory
```

The output contains the installable archive, the Node 20.3-compatible `write.mjs` and `stop.mjs` hooks, and `artifacts.json` with the source commit, input digests, and artifact digests.

```bash
# Type check
npm run typecheck

# Unit & integration test suite (98 test files / 906 tests)
npm test

# Build executable distribution
npm run build

# Package archive & isolated installation acceptance
npm run test:package

# Dogfood installed workflow acceptance (judges this repository: proven)
npm run test:dogfood

# Vacuity harness (ensures all 19 obligations have teeth)
npm run measure:vacuity

# Benchmarks (software sidecar & cross-domain review)
npm run benchmark:run
npm run benchmark:cross-domain

# Self-judgement against this repository's own norms (proven, 0 gaps)
npm run judge:self
```

The accepted baseline uses version 2 ([schema](docs/baseline.schema.json)): numeric `values`,
`moduleFunctionSeed` (initially 20), and `moduleFunctionCeilings` keyed by workspace-relative POSIX paths.
New paths use the seed; deleted paths are ignored; renames are deletion plus a new path. Explicit acceptance
records current counts, including decreases. A flat numeric baseline requires migration by acceptance.
Capture `normproof baseline accept --json` to retain `baselineMigration.staleBaselineEntries`.
See the [operator guide](docs/USER_GUIDE.md) for conflict and uncertain-write recovery.
